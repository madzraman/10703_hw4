export PYTHONPATH=${PWD}:$PYTHONPATH
python scripts/runner.py configs/InvertedPendulum.yml